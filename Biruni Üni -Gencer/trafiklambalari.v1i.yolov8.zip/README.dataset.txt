# traffic > 2024-04-29 4:22pm
https://universe.roboflow.com/traffic-iphpi/traffic-tncts

Provided by a Roboflow user
License: CC BY 4.0

